var content_menu =
'<ul>' +
    '<li><a href="p01.html" target="_self">Table of contents</a></li>' +
    '<li><a href="p02.html" target="_self">1. Multiple choice</a></li>' +
    '<li><a href="p03.html" target="_self">2. Select</a></li>' +
    '<li><a href="p04.html" target="_self">3. Drag and drop</a></li>' +
    '<li><a href="p05.html" target="_self">4. Multiple unique answer</a></li>' +
    '<li><a href="p06.html" target="_self">5. Multiples answers</a></li>' +
    '<li><a href="p07.html" target="_self">6. False and True</a></li>' +
    '<li><a href="p08.html" target="_self">7. Drag and drop images</a></li>' +
    '<li><a href="p09.html" target="_self">8. Accordion select</a></li>' +
    '<li><a href="p10.html" target="_self">9. Crossword puzzle</a></li>' +
    '<li><a href="p11.html" target="_self">10. Evaluate big content</a></li>' +
    '<li><a href="p12.html" target="_self">11. Concentrate</a></li>' +
'</ul>';