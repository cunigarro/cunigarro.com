<h1>E-learning activities 1.0</h1>

E-learning activities is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0) (http://creativecommons.org/licenses/by/3.0/) and MIT License - http://opensource.org/licenses/mit-license.html.

You are allowed to use these elements anywhere and modify it if you want.

<h2>List of activities:</h2>

This group of components allow us to create self-assessment activities for online courses through blocks of code that will guide us through his development. 

Each design has a default design but you can also replace the images to fit your design. 

These are the following activities:

<ol>
  <li><strong>Multiple choice</strong></li>
  <li><strong>Select</strong></li>
  <li><strong>Drag and drop</strong></li>
  <li><strong>Multiple unique answer</strong></li>
  <li><strong>Multiples answers</strong></li>
  <li><strong>False and True</strong></li>
  <li><strong>Drag and drop images</strong></li>
  <li><strong>Accordion select</strong></li>
  <li><strong>Crossword</strong></li>
  <li><strong>Evaluate big content</strong></li>
  <li><strong>Concentrate</strong></li>
</ol>
